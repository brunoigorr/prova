import 'package:flutter/material.dart';
import 'dart:math';

class AppTesoura extends StatefulWidget {
  _AppTesouraState createState() => _AppTesouraState();
}

class _AppTesouraState extends State<AppTesoura> {
  var _imagemvazia = AssetImage('asset/image/imagemvazia.png');
  String _resultado = '';

  void _escolha(String Jogador) {
    var escolha = ["pedra", "papel", "tesoura"];
    var num = Random().nextInt(3);
    var escolhaBoot = escolha[num];

    setState(() {
      if (escolhaBoot == "pedra") {
        _imagemvazia = AssetImage('asset/image/rock.jpg');
      } else if (escolhaBoot == "papel") {
        _imagemvazia = AssetImage('asset/image/paper.png');
      } else if (escolhaBoot == "scissors") {
        _imagemvazia = AssetImage('asset/image/scissors.png');
      }
    });

    //condições pra quem ganhou
    setState(() {
      if ((escolha == "pedra" && escolhaBoot == "tesoura") ||
          (escolha == "tesoura" && escolhaBoot == "papel") ||
          (escolha == "papel" && escolhaBoot == "pedra")) {
        _resultado = "Você ganhou";
      } else if ((escolha == "tesoura" && escolhaBoot == "pedra") ||
          (escolha == "pedra" && escolhaBoot == "tesoura") ||
          (escolha == "pedra" && escolhaBoot == "papel")) {
        _resultado = "Voce perdeu";
      } else {
        _resultado = "Empatamos";
      }
      _mostrarSnackBar();
    });
  }

  void _mostrarSnackBar() {
    final snackBar = SnackBar(
      content: Center(
        child: Column(children: [
          Container(
            height: 300,
          ),
          Text(
            _resultado,
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          )
          //imagem
        ]),
      ),
      duration: Duration(seconds: 2),
      backgroundColor: Colors.orange,
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Pedra, Papel e Tesoura',
          style: TextStyle(
              fontSize: 20, color: Colors.blue, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        toolbarHeight: 80,
      ),
      body: Center(
          child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(32.0),
            child: Text(
              'Escolha da maquina',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          //image
          Padding(
            padding: const EdgeInsets.all(32.0),
            child: Text(
              'Escolha uma opção abaixo',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(5.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: () => _escolha('pedra'),
                  child: Image(
                    image: AssetImage('asset/image/rock.jpg'),
                    height: 110,
                  ),
                ),
                GestureDetector(
                  onTap: () => _escolha('papel'),
                  child: Image(
                    image: AssetImage('asset/image/paper.jpg'),
                    height: 110,
                  ),
                ),
                GestureDetector(
                  onTap: () => _escolha('tesoura'),
                  child: Image(
                    image: AssetImage('asset/image/scissors.jpg'),
                    height: 110,
                  ),
                ),
              ],
            ),
          )
        ],
      )),
    );
  }
}
