import 'package:flutter/material.dart';
import 'app_tesoura.dart';

void main() => runApp(AppTesoura());
